from django.contrib import admin
from questions.models import Answer, Question

admin.site.register(Answer)
admin.site.register(Question)
